#include "circulo.h"

Circulo::Circulo(double radio, QString nombre) : rad(radio), name(nombre)
{}


#ifndef POSTGRESDATA_H
#define POSTGRESDATA_H
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlRecord>
#include <QVariant>
#include "circulo.h"
#include "cono.h"
#include <vector>


class postgresdata
{
public:

    postgresdata();
    ~postgresdata();
    QSqlDatabase db;
    bool connect();
    bool isOpen();
    vector<Circulo*> getlistaConos();
    cono* getCono(QString nombre);
    bool insertCono(cono* nuevoCono);

};

#endif // POSTGRESDATA_H

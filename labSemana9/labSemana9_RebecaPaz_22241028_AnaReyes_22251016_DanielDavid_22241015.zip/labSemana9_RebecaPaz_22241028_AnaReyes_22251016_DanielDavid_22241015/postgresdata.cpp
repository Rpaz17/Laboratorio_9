#include "postgresdata.h"

postgresdata::postgresdata()
{
    db = QSqlDatabase::addDatabase("QPSQL");
}

postgresdata::~postgresdata()
{
  db.close();
}

bool postgresdata::connect()
{

    db.setHostName("BeckyPaz-LT");
    db.setDatabaseName("FigurasG");
    db.setUserName("postgres");
    db.setPassword("SqL_ser_170905@pg");
    bool ok = db.open();
    return ok;
}

bool postgresdata::isOpen()
{
    bool open = db.isOpen();
    return open;
}

vector<Circulo *> postgresdata::getlistaConos()
{
    QSqlQuery query("SELECT * FROM Conos");
    vector<Circulo *> listaConos;
    int iNombre = query.record().indexOf("Nombre");
    int iRadio = query.record().indexOf("Radio");
    int iAltura = query.record().indexOf("Altura");
    while (query.next()) {
        QString Nombre= query.value(iNombre).toString();
        double Radio = query.value(iRadio).toDouble();
        double Altura = query.value(iAltura).toDouble();
        cono* nuevoCono = new cono(Radio, Altura, Nombre.toStdString());
        listaConos.push_back(nuevoCono);
    }
    return listaConos;
}

cono* postgresdata::getCono(QString nombre)
{
    QSqlQuery query;
    query.prepare("SELECT * FROM Conos WHERE Nombre = :nombreCono");
    query.bindValue(":nombreCono", nombre);
    query.exec();
    int iNombre = query.record().indexOf("Nombre");
    int iRadio = query.record().indexOf("Radio");
    int iAltura = query.record().indexOf("Altura");
    QString Nombre= query.value(iNombre).toString();
    double Radio = query.value(iRadio).toDouble();
    double Altura = query.value(iAltura).toDouble();
    cono* nuevoCono = new cono(Radio, Altura, Nombre.toStdString());
    return nuevoCono;
}

bool postgresdata::insertCono(cono* nuevoCono)
{
    QString name = QString::fromStdString(nuevoCono->getNombre());
    cono* Cono = getCono(name);
    if(!Cono->getNombre().empty()){
        QSqlQuery query;
        query.prepare("INSERT INTO Conos (Nombre, Radio, Altura) "
                      "VALUES (:nombre, :radio, :altura)");
        query.bindValue(":nombre", name);
        query.bindValue(":radio", nuevoCono->getRad());
        query.bindValue(":altura", nuevoCono->getAltura());
        query.exec();
        return true;
    }else{
        return false;
    }
}


